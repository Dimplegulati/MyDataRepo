package myspring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class HelloController {
	@RequestMapping("/home")
	public String getHome()
	{
		return "Welcome";
		//it will search for Welcome.jsp in result folder
	}

}
