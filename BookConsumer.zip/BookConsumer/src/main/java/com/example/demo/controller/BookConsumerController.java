package com.example.demo.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Book;

@RestController
@RequestMapping("/consumer")
public class BookConsumerController {
	String baseurl="http://localhost:5041";
	@Autowired
	RestTemplate restTemplate;
	@GetMapping("/retreive")
	public List<Book> retreiveData()
	{
		Book booklist[]=restTemplate.getForObject(baseurl+"/retreiveBooks", Book[].class);
		return Arrays.asList(booklist);
		
	}
	
	

}
