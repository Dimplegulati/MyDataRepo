package com.example.BookManagement.controller;


import org.springframework.beans.factory.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.BookManagement.exceptions.BookNotFoundException;
import com.example.BookManagement.model.Book;
import com.example.BookManagement.model.BookRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
@CrossOrigin("http://localhost:4200")
public class BookController {
    @Autowired
    private BookRepository bookRepo;

    @PostMapping
    public Book createBook(@RequestBody Book book) {
        return bookRepo.save(book);
    }

	@GetMapping("/retrieveByBook/:bookid")

	public Book retrieve(@PathVariable("bookid") long id) {
		Optional<Book> project = bookRepo.findById(id);

		if (project.isEmpty()) {
			return null;
		} else {
			return project.get();
		}

	}
	@GetMapping("/retreiveBooks")
	public List<Book> display()
	{
		return bookRepo.findAll();
	}
	@GetMapping("/bookdet/{bookid}")
	public ResponseEntity<Book> bookbyid(@PathVariable("bookid") Long id)
	{
		Book b=bookRepo.findById(id).orElseThrow(()->new BookNotFoundException());
		return ResponseEntity.ok(b);
	}
	
	@PostMapping("/insert")
	public Book insertData(@RequestBody Book bk) {
		return bookRepo.save(bk);
	}
	@DeleteMapping("/deleteBook/{bookid}")
	public void deleteData(@PathVariable("bookid") Long id)
	{
		bookRepo.deleteById(id);
	}
	@PutMapping("/updateBook/{bookid}")
	public ResponseEntity<Book> updateBook(@PathVariable("bookid") Long id,@RequestBody
			Book b1)
	{
		Book b=bookRepo.findById(id).orElseThrow(()->new BookNotFoundException());;
	System.out.println("Value coming in backend is "+b1.getBookprice());
		b.setBookid(b1.getBookid());
		b.setBooktitle(b1.getBooktitle());
		b.setBookprice(b1.getBookprice());
		b.setGenre(b1.getGenre());
		System.out.println("Price is "+b1.getBookprice());
		System.out.println("updated vaue is "+b.getBookprice());
		Book updatedbook=bookRepo.save(b);
		return ResponseEntity.ok(updatedbook);
	}
	
}