package com.example.BookManagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.BookManagement.model.User;
import com.example.BookManagement.model.UserRepository;

@RestController
public class UserController {
	@Autowired
	UserRepository userrep;
	@PostMapping("/login")
	public ResponseEntity<User> Login(@RequestBody User u1)
	{
		
		User userobj=userrep.findByUsernameAndPassword(u1.getUsername(), u1.getPassword());
		return ResponseEntity.ok(userobj);
	}

}
