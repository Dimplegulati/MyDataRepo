package com.example.BookManagement.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(BookNotFoundException.class)
	public ResponseEntity<Object> exceptionHandler(BookNotFoundException ex)
	{
		String message="unable to find book";
		return new ResponseEntity<>(message,HttpStatus.NOT_FOUND);

	}

}
