package com.example.BookManagement.exceptions;

public class BookNotFoundException extends RuntimeException {

}
