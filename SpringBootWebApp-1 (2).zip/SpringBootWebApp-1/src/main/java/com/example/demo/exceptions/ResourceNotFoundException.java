package com.example.demo.exceptions;

public class ResourceNotFoundException extends RuntimeException {
	@Override
	public String getMessage()
	{
		return "Resource does not exist";
	}

}
