package com.example.demo.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectRepository extends JpaRepository<Project,Integer>{
public List<Project> findByProjecttitle(String name);
public List<Project> findByOrderByProjecttitleAsc();
//Desc
//select * from Project order by projecttitleasc

/*
 * Select * from Project where projecttitle=name
 */
}
