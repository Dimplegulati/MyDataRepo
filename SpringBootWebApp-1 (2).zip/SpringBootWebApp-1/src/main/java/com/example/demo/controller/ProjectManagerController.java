package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.ProjectManager;
import com.example.demo.model.ProjectManagerRepository;

@RestController
public class ProjectManagerController {
	@Autowired
	ProjectManagerRepository projectrep;
	@PostMapping("/insertDetails")
	public ProjectManager insert(@RequestBody ProjectManager pm)
	{
		return projectrep.save(pm);
	}

}
