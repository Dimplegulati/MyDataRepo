package com.example.demo.onetomany.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.onetomany.Department;
import com.example.demo.onetomany.DepartmentRepository;
import com.example.demo.onetomany.Employee;

@RestController
public class DepartmentController {
	@Autowired
	DepartmentRepository deptrep;
	
	@PostMapping("/departmentinsert")
	public Department insertDepartment(@RequestBody Department d)
	{
		return deptrep.save(d);
	}
	@DeleteMapping("/deleteDepartment/{id}")
	public void deleteData(@PathVariable("id") int deptid)
	{
		 deptrep.deleteById(deptid);
	}
	@GetMapping("/retreiveEmployee/{deptid}")
	public List<Employee> retreiveEmployeelist(@PathVariable("deptid") int deptcode)
	{
		return deptrep.findById(deptcode).get().getEmplist();
	}

}
