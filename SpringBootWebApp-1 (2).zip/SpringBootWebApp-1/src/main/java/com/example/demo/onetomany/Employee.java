package com.example.demo.onetomany;
import jakarta.persistence.*;
@Entity
@Table(name="EmployeeRelation")
public class Employee {
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Id
	@Column(name="Employeeid")
	private int empid;
	@Column(name="Employeename")
	private String empname;
	@Column(name="Salary")
	private double salary;
}
