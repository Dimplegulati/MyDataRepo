package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.ResourceNotFoundException;
import com.example.demo.model.Project;
import com.example.demo.model.ProjectRepository;

@RestController
@RequestMapping("/projects")
/*RestController is a combination of Controller and Response Entity*/
public class ProjectController {
	@Autowired
	ProjectRepository projectrep;
	/*
	 * GetMapping
	 * PostMapping
	 * DeleteMapping
	 * PutMapping
	 */
	//http://localhost:8080/projects/retreive
	@GetMapping("/retreive")
	public List<Project> retreiveData()
	{
		return projectrep.findAll();
		
	}
	@GetMapping("/retreiveByProjectcode/{projectid}")
	public ResponseEntity<Project> retreive(@PathVariable("projectid") int id)
	{
		System.out.println("welcome here");
		Project p=projectrep.findById(id).orElseThrow(()->
		new ResourceNotFoundException());
		return new ResponseEntity<>(p,HttpStatus.OK);
		//return ResponseEntity.ok().body(p);
		
	}	
	
	@PostMapping("/insert")
	public Project insertData(@RequestBody Project prj )
	{
		return projectrep.save(prj);
	}
	@GetMapping("/sorting")
	public List<Project> sortdata()
	{
		return projectrep.findByOrderByProjecttitleAsc();
	}

}
