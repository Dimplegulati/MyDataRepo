package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.*;
@Entity
@Table(name="proectmanager")
public class ProjectManager {
	@Id
	@Column(name="Employeid")
	private int employeeid;
	public int getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public int getExperianceyear() {
		return experianceyear;
	}
	public void setExperianceyear(int experianceyear) {
		this.experianceyear = experianceyear;
	}
	public Project getProject() {
		return project;
	}
	public void setProject(Project project) {
		this.project = project;
	}
	@Column(name="Firstname")
	private String firstname;
	@Column(name="Experianceyear")
	private int experianceyear;
	@OneToOne(targetEntity=Project.class)
	@JoinColumn(name="projectcode")
	private Project project;

}
