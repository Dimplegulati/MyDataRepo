package com.example.demo.model;
import jakarta.persistence.*;
@Entity
@Table(name="Projectdata")
public class Project {
	@Id
	@Column(name="projectcode")
	private int projectcode;
	public int getProjectcode() {
		return projectcode;
	}
	public void setProjectcode(int projectcode) {
		this.projectcode = projectcode;
	}
	public String getProjecttitle() {
		return projecttitle;
	}
	public void setProjecttitle(String projecttitle) {
		this.projecttitle = projecttitle;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	@Column(name="projecttitle")
	private String projecttitle;
	@Column(name="duration")
	private int duration;
	
	
	

}
