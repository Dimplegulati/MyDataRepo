package com.wipro.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.demo.entities.AuthRequest;
import com.wipro.demo.entities.UserInfo;
import com.wipro.demo.service.JwtService;
import com.wipro.demo.service.UserInfoService;

@RestController
@RequestMapping("/authentication")
public class UserController {
	@Autowired
	UserInfoService userservice;
	@Autowired
	JwtService jwtService;
	@Autowired
	AuthenticationManager authManager;
	@GetMapping("/welcome")
	public String welcomePage()
	{
		return "Welcome to Main endpoint";
	}
	@PostMapping("/addUser")
	public String addNewUser(@RequestBody UserInfo userinfo)
	{
		return userservice.addUser(userinfo);
	}
	@GetMapping("/userPage")
	@PreAuthorize("hasAuthority('USER')")
	public String userPAge()
	{
		return "Welcoe to User Page";
	}
	
	@GetMapping("/adminPage")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String adminPage()
	{
		return "Welcoe to Admin Page";
	}
	@PostMapping("/generateToken")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
		System.out.println("username "+authRequest.getUsername());
		System.out.println("Password is "+authRequest.getPassword());
        Authentication authentication = authManager.authenticate(
            new UsernamePasswordAuthenticationToken(authRequest.getUsername(), 
            		authRequest.getPassword())
        );
        if (authentication.isAuthenticated()) {
        	System.out.println("Coming hre");
            return jwtService.generateToken(authRequest.getUsername());
        } else {
            throw new UsernameNotFoundException("Invalid user request!");
        }
    }

	

}
