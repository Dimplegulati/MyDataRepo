package com.wipro.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.demo.dao.EmployeeDAO;
import com.wipro.demo.model.Employee;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeDAO emprep;
	@RequestMapping("/hello")
	public String getPage()
	{
		System.out.println("Coming here");
		return "Welcome";
	}
	@RequestMapping("/empdata")
	public ModelAndView displayData()
	{
		Employee e=new Employee();
		e.setEmpid(1);
		e.setEmpname("Naman");
		e.setSalary(80000);
		return new ModelAndView("EmployeeFirst","edata",e);
	}
	@RequestMapping("/EmpForm")
	public ModelAndView displayForm()
	{
		return new ModelAndView("EmployeeForm","eobj",new Employee());
	}
	@RequestMapping(value="insertEmployee",method=RequestMethod.POST)
	public String insertData(@ModelAttribute("eobj")Employee e1)
	{
		System.out.println("Employee Name is"+e1.getEmpname());
		emprep.insertEmployee(e1);
		return "success";
	}
	@RequestMapping("/RetreiveForm")
	public ModelAndView displayRetreiveForm()
	{
		System.out.println("hello");
		return new ModelAndView("RetreiveForm","retreivedata",new Employee());
	}
	@RequestMapping(value="/RetreiveData",method=RequestMethod.POST)
	public ModelAndView retreiveData(@ModelAttribute("retreivedata") Employee e1)
	{
		Employee eupdate=emprep.retreiveData(e1.getEmpid());
		return new ModelAndView("UpdateForm","updatedata",eupdate);
	}
	@RequestMapping(value="/updateEmployee",method=RequestMethod.POST)
	public String updateData(@ModelAttribute("updatedata")Employee eupdate)
	{
		emprep.updateEmployee(eupdate);
		return "success";
	}
}
