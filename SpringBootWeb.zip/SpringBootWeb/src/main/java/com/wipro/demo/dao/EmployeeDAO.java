package com.wipro.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.wipro.demo.model.Employee;
@Repository
public class EmployeeDAO {
	@Autowired
	JdbcTemplate jdbctemp;
	public void insertEmployee(Employee e)
	{
		String insertQuery="insert into employees values(?,?,?)";
		int result=jdbctemp.update(insertQuery,e.getEmpid(),e.getEmpname(),e.getSalary());
		
		if(result>0)
		{
			System.out.println("Data inserted");
		}
	}
	public Employee retreiveData(int eid)
	{
		String query="select * from employees where empid=?";
	Employee retreiveobj=jdbctemp.queryForObject(query,new Object[] {eid},new EmployeeRowMapper());
	return retreiveobj;
		
	}
	public void updateEmployee(Employee e)
	{
		String query="update Employees set empname=?,salary=? where empid=?";
		int result=jdbctemp.update(query,e.getEmpname(),e.getSalary(),e.getEmpid());
		if(result>0)
		{
			System.out.println("updated");
		}
	}
}
class EmployeeRowMapper implements RowMapper<Employee>
{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Employee e=new Employee();
		e.setEmpid(rs.getInt(1));
		e.setEmpname(rs.getString(2));
		e.setSalary(rs.getDouble(3));
		return e;
	}
	
}
